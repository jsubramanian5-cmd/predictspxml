Scope: Cboe SPX/SPXW, assumed from preceding settlement requests.

Contains official annual options expiration calendar PDFs for 2020-2026, listing-change notices and reference snapshots. Calendar PDFs mark holidays, expiration types and last-trading dates. No earlier calendar PDF was located in the checked Cboe archive URL pattern.

This is a source-document archive, not a complete historical per-contract eligibility dataset. Launch announcements and listing rules do not prove which exact strike/expiry contracts were tradable on each historical date. Historical series/chain records require a separate source, potentially licensed data. No licensed data was purchased.

Files ending current.html are current reference snapshots downloaded 2026-11-07, not historical snapshots. See manifests for source URLs.
